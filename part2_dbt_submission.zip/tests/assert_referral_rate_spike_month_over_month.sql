-- assert_referral_rate_spike_month_over_month.sql

WITH current_and_previous_rates AS (
    SELECT
        consultation_month,
        doctor_issued_referral_rate_pct AS current_rate,
        lag(doctor_issued_referral_rate_pct) OVER (ORDER BY consultation_month) AS previous_rate
    FROM {{ ref('mart_referral_rate_monthly') }}
)

SELECT
    consultation_month,
    current_rate,
    previous_rate,
    abs(current_rate - previous_rate) AS absolute_difference
FROM current_and_previous_rates
WHERE previous_rate IS NOT NULL
  -- Fail if the referral rate jumps or drops by more than 5 percentage points month-over-month.
  -- The 11% to 28% jump (17 percentage points) would easily trigger this failure.
  AND abs(current_rate - previous_rate) > 5.0
