# Irembo TeleClinic Analytics Engineer Assignment

## Assumptions about Source Schema
- The raw `consultations` table contains timestamps as string-like formats (e.g., `'Apr 4 08:49 UTC'`, `'Apr 5 14:13 UTC+2'`) which requires parsing using `parseDateTimeBestEffort` in ClickHouse.
- `stg_clinical_outcomes` and `stg_consultation_requests` have already been cleaned to provide boolean columns (`referral_issued`, `referral_requested`) mapped correctly to `consultation_id`.
- The wait time threshold for a valid consultation is assumed to be between 0 and 1440 minutes (24 hours). Anything outside this range is treated as an invalid or implausible data point and set to `NULL`.
- The `patient_id` column contains a standard string format where test accounts are prefixed with `'TEST_'`.

## AI Tools Usage
AI tools (specifically an LLM assistant) were used to assist in structuring the written responses for clarity and conciseness. AI was also utilized to scaffold the initial dbt model boilerplate and test YAML structures, which were then manually reviewed, refined, and adapted to ensure correctness in ClickHouse syntax (e.g., `toTimeZone`, `parseDateTimeBestEffort`) and logical accuracy according to the assignment requirements. The diagnostic reasoning and final metric definitions are my own.
